# Usage

```bash
bash mkdir.sh
bash runapp.sh
bash showres.sh
```
