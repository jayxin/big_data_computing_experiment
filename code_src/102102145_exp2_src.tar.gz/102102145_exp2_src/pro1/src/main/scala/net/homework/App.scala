package net.homework;

import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.apache.spark.SparkContext._

import java.nio.file.Paths

object App {
  def main(args : Array[String]) : Unit = {
    val cwd = Paths.get("").toAbsolutePath.toString

    val inputPath = "file://" + cwd + "/input"
    val outputPath = "file://" + cwd + "/output"
    val inputFile0 = inputPath + "/A.txt"
    val inputFile1 = inputPath + "/B.txt"

    val conf = new SparkConf().setMaster("local").setAppName("pro1");
    val sc = new SparkContext(conf)

    val input0 = sc.textFile(inputFile0)
    val input1 = sc.textFile(inputFile1)

    val unionRes = input0.union(input1)

    val res = unionRes.distinct.sortBy(_.split(" ")(0))
    res.saveAsTextFile(outputPath)
  }
}
