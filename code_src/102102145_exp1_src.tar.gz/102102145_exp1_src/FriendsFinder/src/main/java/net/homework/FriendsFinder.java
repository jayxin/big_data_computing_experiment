package net.homework;

import java.io.IOException;
import java.util.HashSet;
import java.util.ArrayList;
import java.util.Collections;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;

import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;

class AppMapper extends Mapper<LongWritable, Text, Text, Text> {
  Text k = new Text(); // out-key

  @Override
  protected void map(LongWritable key, Text value, Context context)
  throws IOException, InterruptedException {
    String line = value.toString();
    String[] arr = line.split("<");
    String user = arr[0],
           fans = arr[1];
    String[] fansArr = fans.split(",");

    k.set(user);

    for (int i = 0; i < fansArr.length; i++) {
      if (user.compareTo(fansArr[i]) <= 0) {
        context.write(k, new Text(fansArr[i]));
      } else {
        context.write(new Text(fansArr[i]), k);
      }
    }
  }
}

class AppReducer extends Reducer<Text, Text, Text, Text> {
  @Override
  protected void reduce(Text key, Iterable<Text> values, Context context)
  throws IOException, InterruptedException {
    HashSet<String> set = new HashSet<String>();
    ArrayList<String> fansList = new ArrayList<String>();
    for (Text item : values) {
      String fan = item.toString();
      if (set.contains(fan)) {
        fansList.add(fan);
      } else {
        set.add(fan);
      }
    }
    Collections.sort(fansList);
    for (String item : fansList) {
        context.write(key, new Text(item));
    }
  }
}

public class FriendsFinder {
  public static void main(String[] args)
  throws IOException, ClassNotFoundException, InterruptedException {
    Configuration conf = new Configuration();

    conf.set("mapred.textoutputformat.ignoreseparator", "true");
    conf.set("mapred.textoutputformat.separator", "<->");

    Job job = Job.getInstance(conf);

    job.setJarByClass(FriendsFinder.class);

    job.setMapperClass(AppMapper.class);
    job.setReducerClass(AppReducer.class);

    job.setMapOutputKeyClass(Text.class);
    job.setMapOutputValueClass(Text.class);

    job.setOutputKeyClass(Text.class);
    job.setOutputValueClass(Text.class);

    FileInputFormat.setInputPaths(job, new Path(args[0]));
    FileOutputFormat.setOutputPath(job, new Path(args[1]));

    boolean result = job.waitForCompletion(true);
    System.exit(result ? 0 : 1);
  }
}
