#!/bin/bash

hdfs dfs -mkdir -p input/pro1
hdfs dfs -put ./input/words.txt input/pro1
hdfs dfs -mkdir -p output
