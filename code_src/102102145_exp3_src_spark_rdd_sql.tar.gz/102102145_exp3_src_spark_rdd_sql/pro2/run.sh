#!/bin/bash

mvn package -DskipTests

if [[ $? -gt 0 ]] ; then
  exit 1
fi

$SPARK_HOME/bin/spark-submit --class net.homework.App \
  ./target/pro2-1.0-SNAPSHOT.jar
