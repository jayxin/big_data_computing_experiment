package net.homework

import org.apache.spark.SparkContext._
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.Row
import org.apache.spark.sql.functions.{desc, expr, row_number, col}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.types.{
  StructField, StructType,
  StringType, LongType, DoubleType
}

import java.nio.file.Paths

object App {
  def main(args : Array[String]) : Unit = {
    val spark = SparkSession.builder().appName("pro2").getOrCreate()

    val cwd = Paths.get("").toAbsolutePath.toString
    val inputPath = s"file://${cwd}/input"

    val schema = new StructType(Array(
      new StructField("qiudui", StringType, true),
      new StructField("saiji", StringType, true),
      new StructField("toulan", StringType, true),
      new StructField("mingzhong0", StringType, true),
      new StructField("chushou0", StringType, true),
      new StructField("sanfen", StringType, true),
      new StructField("mingzhong1", StringType, true),
      new StructField("chushou1", StringType, true),
      new StructField("faqiu", StringType, true),
      new StructField("mingzhong2", StringType, true),
      new StructField("chushou2", StringType, true),
      new StructField("lanban", StringType, true),
      new StructField("qianchang", StringType, true),
      new StructField("houchang", StringType, true),
      new StructField("zhugong", StringType, true),
      new StructField("qianduan", StringType, true),
      new StructField("gaimao", StringType, true),
      new StructField("shiwu", StringType, true),
      new StructField("fangui", StringType, true),
      new StructField("defen", DoubleType, true),
      new StructField("shifen", DoubleType, true),
      new StructField("sheng", LongType, true),
      new StructField("fu", LongType, true),
      new StructField("gongshi", DoubleType, true),
      new StructField("lianmeng", StringType, true),
    ))

    val df = spark.read
      .option("header", "true")
      .option("inferSchema", "false")
      .schema(schema)
      .format("csv")
      .load(s"${inputPath}/NBA14-16.csv")
    df.cache()
    //球队,赛季,投篮,命中,出手,三分,命中,出手,罚球,命中,出手,篮板,前场,后场,助攻,抢断,盖帽,失误,犯规,得分,失分,胜,负,公式,联盟
    //金州勇士,14-15,47.80%,41.6,87,39.80%,10.8,27,76.80%,16,20.8,44.7,10.4,34.3,27.4,9.3,6,14.1,19.9,110,99.8,67,15,81.7,west

    //\item 根据胜负场次统计 $ 15 $ - $ 16 $ 赛季都能够进入季后赛的球队
    //(查询东西部联盟排名前 $ 8 $ 的球队)
    df.where("saiji like '15%16'")
      .orderBy(desc("sheng"))
      .take(8)
      .foreach(println)
    println("======")

    //\item 针对最近两个赛季常规赛排名, 根据排名的变化, 找出东、西部进步幅度最大的球队。
    val df1 = df.withColumn("score", expr("defen - shifen"))
    val windowSpec = Window.partitionBy("saiji")
      .orderBy(col("score").desc)
      .rowsBetween(Window.unboundedPreceding, Window.currentRow)
    val df2 = df1.withColumn("rank", row_number().over(windowSpec))
    df2.createOrReplaceTempView("df2_view")
    spark.sql("""
      SELECT x.qiudui, x.rank-y.rank AS rdiff FROM
      df2_view x, df2_view y
      WHERE x.qiudui=y.qiudui AND x.saiji LIKE '14%' AND y.saiji LIKE '15%'
      """)
      .where("rdiff >= 0")
      .orderBy(desc("rdiff"))
      .take(1)
      .foreach(println)
    println("======")

    //\item 分析统计出 $ 15 $ - $ 16 $ 赛季命中率(第三列)、 三分球命中率(第六列)、
    //防守能力最强(失分越少防守越强)的三支球队.
    df.select("qiudui", "toulan", "sanfen", "shifen")
      .orderBy("shifen")
      .take(3)
      .foreach(println)
    println("======")

    spark.stop()
  }
}
