#!/bin/bash

APP_NAME='net.homework.FriendsFinder'
INPUT_DIR='input/pro3'
OUTPUT_DIR='output/pro3'

hdfs dfs -rm -r "$OUTPUT_DIR" 2>/dev/null

cd target
hadoop jar *.jar "$APP_NAME" "$INPUT_DIR" "$OUTPUT_DIR"
