package net.homework;

import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.apache.spark.SparkContext._

import java.nio.file.Paths
import java.io.File

object App {
  def main(args : Array[String]) : Unit = {
    val cwd = Paths.get("").toAbsolutePath.toString

    val inputPath = "file://" + cwd + "/input"
    val outputPath = "file://" + cwd + "/output"

    val conf = new SparkConf().setMaster("local").setAppName("pro2");
    val sc = new SparkContext(conf)

    val textData = sc.wholeTextFiles(inputPath)
    val textContent = textData.map(_._2).flatMap(_.split("\n"))

    val dir = new File(s"${cwd}/input")
    var subjectCount : Double = 1
    if (dir.isDirectory) {
      subjectCount = dir.listFiles().count(_.isFile)
    }

    val res = textContent.map(
      x => (x.split("\t")(0), x.split("\t")(1).toInt)
    ).reduceByKey(
      (val1, val2) => val1 + val2
    ).map(
      x => (x._1, f"${x._2/subjectCount}%.2f")
    )

    res.saveAsTextFile(outputPath)
  }
}
