package net.homework;

import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.apache.spark.SparkContext._

import java.nio.file.Paths
import java.io.File

object App {
  def main(args : Array[String]) : Unit = {
    val cwd = Paths.get("").toAbsolutePath.toString

    val inputPath = "file://" + cwd + "/input"

    val conf = new SparkConf().setMaster("local").setAppName("pro3");
    val sc = new SparkContext(conf)

    val textData = sc.wholeTextFiles(inputPath)
    val textContent = textData.map(_._2).flatMap(_.split("\n"))

    val people = textContent.map(
      x => {
        val arr = x.split("\t")
        (arr(2).toDouble, arr(1))
      }
    )

    val male = people.filter(x => x._2 == "M").map(_._1)
    val female = people.filter(x => x._2 == "F").map(_._1)

    val numOfMale = male.count
    val numOfFemale = female.count

    val maxHeightOfMale = male.max
    val maxHeightOfFemale = female.max

    val minHeightOfMale = male.min
    val minHeightOfFemale = female.min

    val avgHeightOfMale = male.reduce(
      (val1, val2) => val1 + val2
    ) / numOfMale
    val avgHeightOfFemale = female.reduce(
      (val1, val2) => val1 + val2
    ) / numOfFemale

    println(s"(男性总数, 女性总数): ($numOfMale, $numOfFemale)")
    println(s"(男性最高身高, 女性最高身高): ($maxHeightOfMale, $maxHeightOfFemale)")
    println(s"(男性最低身高, 女性最低身高): ($minHeightOfMale, $minHeightOfFemale)")
    println(s"(男性平均身高, 女性平均身高): ($avgHeightOfMale, $avgHeightOfFemale)")
  }
}
