#!/bin/bash

APP_NAME='net.homework.WordDeduplication'
INPUT_DIR='input/pro1'
OUTPUT_DIR='output/pro1'

hdfs dfs -rm -r "$OUTPUT_DIR" 2>/dev/null

cd target
hadoop jar *.jar "$APP_NAME" "$INPUT_DIR" "$OUTPUT_DIR"
