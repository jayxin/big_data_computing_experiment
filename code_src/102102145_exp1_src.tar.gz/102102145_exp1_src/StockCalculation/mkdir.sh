#!/bin/bash

hdfs dfs -mkdir -p input/pro2
hdfs dfs -put ./input/Stocks.txt input/pro2
hdfs dfs -mkdir -p output
