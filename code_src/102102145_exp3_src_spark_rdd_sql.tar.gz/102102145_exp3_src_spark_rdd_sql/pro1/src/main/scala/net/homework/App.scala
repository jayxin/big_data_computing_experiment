package net.homework;

import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.apache.spark.SparkContext._
import org.apache.spark.rdd.RDD

import java.nio.file.Paths

class SecondarySortKey0(val first : String, val second : String)
extends Ordered [SecondarySortKey0]
with Serializable {
  def compare(other : SecondarySortKey0) : Int = {
    if (!this.first.equals(other.first)) {
      if (this.first > other.first) -1
      else 1
    } else {
      if (this.second > other.second) 1
      else -1
    }
  }
}

class SecondarySortKey1(val first : String, val second : String)
extends Ordered [SecondarySortKey1]
with Serializable {
  def compare(other : SecondarySortKey1) : Int = {
    if (!this.first.equals(other.first)) {
      if (this.first > other.first) 1
      else -1
    } else {
      if (this.second > other.second) -1
      else 1
    }
  }
}

object App {
  def main(args : Array[String]) : Unit = {
    val conf = new SparkConf().setMaster("local").setAppName("pro1");
    val sc = new SparkContext(conf)

    val cwd = Paths.get("").toAbsolutePath.toString
    val inputPath = "file://" + cwd + "/input"

    val userInfoData = sc
      .textFile(inputPath + "/User_Info_Data.txt")
      .map(line => {
        if (line.startsWith("UserID")) ""
        else line
      })
      .filter(_.length != 0)

    val userActivityData = sc
      .textFile(inputPath + "/User_Activity_Data.txt")
      .map(line => {
        if (line.startsWith("UserID")) ""
        else line
      })
      .filter(_.length != 0)

    userInfoData.cache()
    userActivityData.cache()

    //secondarySort(userActivityData)
    //distinctAndStatistics(userActivityData);
    dataJoin(userInfoData, userActivityData);
  }

  def secondarySort(data : RDD[String]) : Unit = {
    // 从给定的数据集中，使用二次排序的方法，首先按照用户 ID 升序排序，然后按
    // 照时间戳降序排序。输出按照排序条件筛选后的前 10 条记录。
    data
    .map(
      x => (new SecondarySortKey0(
        x.split(",")(0).trim,
        x.split(",")(1).trim),
        x)
    )
    .sortByKey(false)
    .map(_._2)
    .take(10)
    .foreach(println)

    println("=========")

    // 从给定的数据集中，使用二次排序的方法，首先按照用户 ID 降序排序，然后按
    // 照事件类型升序排序。输出按照排序条件筛选后的前 10 条记录。
    data
    .map(
      x => (new SecondarySortKey1(
        x.split(",")(0).trim,
        x.split(",")(2).trim),
        x)
    )
    .sortByKey(false)
    .map(_._2)
    .take(10)
    .foreach(println)
  }

  def distinctAndStatistics(data : RDD[String]) {
    // 从给定的数据集中，找出重复的事件记录（完全相同的记录），并将它们去重。
    // 输出去重后的数据集。输出的数据格式：用户ID 事件类型 事件内容
    val res = data
      .distinct()
      .map(_.split(",").toList)
      .map(x => (x(2).trim, (x(0).trim, x(3).trim)))

    res
      .foreach(x => println(s"${x._2._1}\t${x._1}\t${x._2._2}"))

    println("========")

    // 对去重后的数据集，统计每种事件类型的数量，并输出事件类型和对应的数量。
    res
      .groupByKey()
      .map(x => (x._1, x._2.size))
      .foreach(println)
  }

  def dataJoin(userInfoData : RDD[String], userActivityData : RDD[String]) {
    val userInfo = userInfoData
      .map(_.split(",").toList)
      .map(x => (x(0).trim, x(1).trim))

    val userActivity = userActivityData
      .map(_.split(",").toList)
      .map(x => (x(0).trim, (x(2).trim, x(3).trim)))

      userInfo.cache()
      userActivity.cache()

      // 从用户信息数据集中读取用户 ID 和用户名称。将两个数据集根据用户 ID 进行连
      // 接，得到一个新的数据集，其中包含用户信息和相关用户行为记录。
      val info = userInfo.join(userActivity)
      info.cache()

      // 对连接后的数据集进行进一步处理，将用户信息和活动详情合并成一个格式化的
      // 字符串，例如："用户名称 - 事件类型 - 事件内容"。
      info
        .map(_._2)
        .map(x => s"${x._1} - ${x._2._1} - ${x._2._2}")
        .foreach(println)

      println("=========")

      // 输出格式化后的报告，包括每个用户的用户名称、事件类型和事件数量。
      // 输出格式为：用户名称--事件类型--事件数量
      info
        .map(_._2)
        .map(x => (s"${x._1}-${x._2._1}", s"${x._2._2}"))
        .groupByKey()
        .map(x => (x._1.split("-")(0), x._1.split("-")(1), x._2.size))
        .foreach(x => println(s"${x._1}--${x._2}--${x._3}"))
  }
}
