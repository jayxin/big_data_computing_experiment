package net.homework;

import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.apache.spark.SparkContext._

import java.nio.file.Paths

object App {
  def main(args : Array[String]) : Unit = {
    val cwd = Paths.get("").toAbsolutePath.toString

    val inputPath = "file://" + cwd + "/input"
    val outputPath = "file://" + cwd + "/output"

    val conf = new SparkConf().setMaster("local").setAppName("pro4");
    val sc = new SparkContext(conf)

    val textData = sc.wholeTextFiles(inputPath)
    val textContent = textData.map(_._2).flatMap(_.split("\n"))

    val res = textContent.map(
      x => {
        val arr = x.split("<")
        (arr(0), arr(1).split(","))
      }
    ).flatMap(
      x => {
        var ret = List((x._1, (x._2.length, 0)))
        for (fan <- x._2) {
          ret = (fan, (0, 1)) +: ret
        }
        ret
    }).reduceByKey(
      (val1, val2) => (val1._1 + val2._1, val1._2 + val2._2)
    ).map(
      x => (x._1, x._2._1, x._2._2)
    ).sortBy(_._1)

    res.saveAsTextFile(outputPath)
  }
}
