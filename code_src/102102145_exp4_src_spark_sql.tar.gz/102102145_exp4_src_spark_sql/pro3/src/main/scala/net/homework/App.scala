package net.homework

import org.apache.spark.{SparkConf, SparkContext}
import org.apache.spark.SparkContext._
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.types.{
  StructField, StructType,
  StringType, LongType, DoubleType
}
import org.apache.spark.sql.Row

import java.nio.file.Paths

object App {
  def main(args : Array[String]) : Unit = {
    val spark = SparkSession
      .builder()
      .appName("pro3")
      .getOrCreate()

    val cwd = Paths.get("").toAbsolutePath.toString
    val inputPath = s"file://${cwd}/input"

    val textData = spark
      .sparkContext
      .textFile(s"${inputPath}/运动会数据.txt")
      .filter(
        x => {
          !x.startsWith("比赛") && x.length > 0
      })
    val rddInfo = textData
      .map(
        x => {
          val arr = x.split(",")
          Row(arr(0).trim, arr(1).trim, arr(2).trim,
            arr(3).trim.toDouble, arr(4).trim.toLong)
      })

    val schema = new StructType(Array(
      new StructField("category", StringType),
      new StructField("class", StringType),
      new StructField("player", StringType),
      new StructField("score", DoubleType),
      new StructField("rank", LongType)
    ))
    //rddInfo.foreach(println)

    val dfInfo = spark.createDataFrame(rddInfo, schema)
    //dfInfo.show()

    dfInfo.createOrReplaceTempView("info")

    // 计算所有比赛项目的平均成绩
    println("计算所有比赛项目的平均成绩:")
    spark
      .sql("""SELECT ROUND(AVG(score), 2) AS Avg_Score
        FROM info
        GROUP BY category""")
      .show()
    println("=======")

    // 统计每个班级获得的第一名、第二名和第三名的次数。
    println("统计每个班级获得的第一名、第二名和第三名的次数:")
    spark
      .sql("""SELECT info.class, COUNT(*) AS First_Num
        FROM info
        WHERE rank=1
        GROUP BY class""")
      .show()
    spark
      .sql("""SELECT info.class, COUNT(*) AS Second_Num
        FROM info
        WHERE rank=2
        GROUP BY class""")
      .show()
    spark
      .sql("""SELECT info.class, COUNT(*) AS Third_Num
        FROM info
        WHERE rank=3
        GROUP BY class""")
      .show()
    println("========")

    // 列出获得第一名次数超过 2 次的班级。
    println("列出获得第一名次数超过 2 次的班级:")
    spark
      .sql("""SELECT info.class, COUNT(*) AS Num
        FROM info
        WHERE rank=1
        GROUP BY class having count(*)>2""")
      .show()
    println("========")

    // 筛选出所有田径项目（如 100 米短跑、200 米短跑）的比赛结果。
    println("筛选出所有田径项目（如 100 米短跑、200 米短跑）的比赛结果:")
    spark
      .sql("""SELECT *
        FROM info
        ORDER BY category, rank""")
      .show()

    // 统计在这些田径项目中获得前三名的个人数量。
    println("统计在这些田径项目中获得前三名的个人数量:")
    spark
      .sql("""SELECT DISTINCT COUNT(*)
        FROM info
        WHERE rank<=3""")
      .show()


    spark.stop()
  }
}
