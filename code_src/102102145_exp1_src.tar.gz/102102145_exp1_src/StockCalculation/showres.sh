#!/bin/bash

OUTPUT_DIR='output/pro2'

hdfs dfs -cat "$OUTPUT_DIR"/*
