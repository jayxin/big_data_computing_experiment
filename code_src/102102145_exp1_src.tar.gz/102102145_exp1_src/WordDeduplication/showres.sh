#!/bin/bash

OUTPUT_DIR='output/pro1'

hdfs dfs -cat "$OUTPUT_DIR"/*
