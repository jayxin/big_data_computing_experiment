#!/bin/bash

hdfs dfs -mkdir -p input/pro3
hdfs dfs -put ./input/relationship.txt input/pro3
hdfs dfs -mkdir -p output
