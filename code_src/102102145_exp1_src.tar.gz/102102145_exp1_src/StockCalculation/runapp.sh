#!/bin/bash

APP_NAME='net.homework.StockCalculation'
INPUT_DIR='input/pro2'
OUTPUT_DIR='output/pro2'

hdfs dfs -rm -r "$OUTPUT_DIR" 2>/dev/null

cd target
hadoop jar *.jar "$APP_NAME" "$INPUT_DIR" "$OUTPUT_DIR"
