package net.homework;

import org.apache.spark.SparkContext._
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions.{collect_list, expr}
import org.apache.spark.sql.types.{
  StructField, StructType,
  StringType, LongType, DoubleType
}
import org.apache.spark.sql.Row

import java.nio.file.Paths

object App {
  def main(args : Array[String]) : Unit = {
    val spark = SparkSession
      .builder()
      .appName("pro1")
      .getOrCreate()

      val cwd = Paths.get("").toAbsolutePath.toString
      val inputPath = s"file://${cwd}/input"

      val df = spark.read.format("json").load(s"${inputPath}/employee.json")
      df.cache()

      // 查询所有数据;
      println("查询所有数据")
      df.selectExpr("*").show()
      println("======")

      // 查询所有数据，并去除重复的数据;
      println("查询所有数据，并去除重复的数据")
      df.selectExpr("*").distinct().show()
      println("======")

      // 查询所有数据，打印时去除 id 字段;
      println("查询所有数据，打印时去除 id 字段")
      df.select("name", "age").distinct().show()
      println("======")

      // 筛选出 age>30 的记录;
      println("筛选出 age>30 的记录")
      df.where("age > 30").show()
      println("======")

      // 将数据按 age 分组;
      println("将数据按 age 分组")
      df.groupBy("age").agg(collect_list("name")).show()
      println("======")

      // 将数据按 name 升序排列;
      println("将数据按 name 升序排列")
      df.orderBy("name").show()
      println("======")

      // 取出前 3 行数据;
      println("取出前 3 行数据")
      df.show(3)
      println("======")

      // 查询所有记录的 name 列，并为其取别名为 username;
      println("查询所有记录的 name 列，并为其取别名为 username")
      df.selectExpr("name AS username").show()
      println("======")

      // 查询年龄 age 的平均值;
      println("查询年龄 age 的平均值")
      df.selectExpr("AVG(age)").show()
      println("======")

      // 查询年龄 age 的最小值。
      println("查询年龄 age 的最小值")
      df.selectExpr("MIN(age)").show()
      println("======")

      spark.stop()
  }
}
