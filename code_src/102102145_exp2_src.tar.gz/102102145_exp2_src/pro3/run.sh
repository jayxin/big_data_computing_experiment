#!/bin/bash

#mvn package -DskipTests

rm -rf output
$SPARK_HOME/bin/spark-submit --class net.homework.App \
  ./target/pro3-1.0-SNAPSHOT.jar
